"""P1: fetch the 360 pinned photographs with the carried fetch_corpus (every file size- and SHA-256-checked; the
cache is re-hashed), build the seed-42 216/48/96 split and its homography pairs with the carried
build_sample_dataset, check disjointness and observer overlap, and score the two non-neural baselines
(identity_baseline, patch_neighbour_baseline) on the 96 test pairs with the carried pair_metrics /
matching_metrics, replicating pipe.evaluate's loop (pipeline.py lines 229-270) without torch."""
import json, sys, time, types, importlib
from pathlib import Path
import numpy as np
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('xoftr_pipeline'); pkg.__path__ = [str(repo / 'src/xoftr_pipeline')]
sys.modules['xoftr_pipeline'] = pkg
S = importlib.import_module('xoftr_pipeline.samples')
M = importlib.import_module('xoftr_pipeline.metrics')
t0 = time.perf_counter()
files = S.fetch_corpus(cache_dir=str(out / 'inat'))
corpus = S.read_corpus(files)
splits = S.build_sample_dataset(corpus, seed=42)
man = {k: S.validate_dataset(v) for k, v in splits.items()}
splits = {k: m['records'] for k, m in man.items()}
res = {'photographs': len(corpus), 'bytes': sum(len(v) for v in files.values()), 'split': {k: len(v) for k, v in splits.items()},
       'tiers': {k: m['tiers'] for k, m in man.items()}, 'disjoint': S.check_split_disjoint(splits), 'observer_overlap': S.observer_overlap(splits),
       'digests': {k: m['digest'][:12] for k, m in man.items()}, 'build_seconds': round(time.perf_counter() - t0, 1)}
def evaluate(records, fn):
    rows = []
    for r in records:
        result = fn(r['image0'], r['image1'])
        size = tuple(result.get('size0', r['image0'].size))
        row = M.pair_metrics(result, np.asarray(r['homography']), (int(size[0]), int(size[1])))
        row.update({'id': r['id'], 'tier': r['tier']}); rows.append(row)
    o = M.matching_metrics(rows)
    o['by_tier'] = {t: {k: v for k, v in M.matching_metrics([x for x in rows if x['tier'] == t]).items() if k != 'definitions'} for t in sorted({x['tier'] for x in rows})}
    return o
KEYS = ('precision_3px', 'precision_1px', 'matches_per_pair', 'inliers_per_pair', 'median_error_px', 'homography_acc_3px', 'homography_acc_5px')
rd = lambda d: {k: (round(d[k], 3) if isinstance(d[k], float) and np.isfinite(d[k]) else d[k]) for k in KEYS}
for name, fn in (('identity', M.identity_baseline), ('patch_neighbour', M.patch_neighbour_baseline)):
    t1 = time.perf_counter(); o = evaluate(splits['test'], fn)
    res[name] = {**rd(o), 'by_tier': {t: rd(v) for t, v in o['by_tier'].items()}, 'seconds': round(time.perf_counter() - t1, 1)}
res['record_2026_09_21'] = {'identity': {'precision_3px': 0.007, 'precision_1px': 0.0, 'matches_per_pair': 267.188, 'inliers_per_pair': 1.896, 'median_error_px': 2.326, 'homography_acc_3px': 0.0},
                            'patch_neighbour': {'precision_3px': 0.381, 'precision_1px': 0.314, 'matches_per_pair': 267.188, 'inliers_per_pair': 101.167, 'median_error_px': 0.546, 'homography_acc_3px': 0.479, 'homography_acc_5px': 0.51},
                            'frozen': {'precision_3px': 0.925, 'homography_acc_3px': 0.979}}
print(json.dumps(res, indent=1, default=str)); (out / 'p1.json').write_text(json.dumps(res, indent=1, default=str))
