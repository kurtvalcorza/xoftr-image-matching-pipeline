"""P2: cell 21's BYOD branch (google.colab stand-in), then the per-split validate_dataset the cell runs next, on
zips of N textured JPEGs, against the stated 'at least eight' photographs; plus a cancelled dialog, a zip with no
JPEG/PNG, a corrupt JPEG and a too-small image."""
import io, json, os, sys, types, zipfile, importlib, tempfile
from pathlib import Path
import numpy as np
from PIL import Image
repo, out = Path(sys.argv[1]), Path(sys.argv[2]).resolve()
pkg = types.ModuleType('xoftr_pipeline'); pkg.__path__ = [str(repo / 'src/xoftr_pipeline')]
sys.modules['xoftr_pipeline'] = pkg
S = importlib.import_module('xoftr_pipeline.samples')
def jpg(seed, size=(320, 240)):
    a = (np.random.default_rng(seed).integers(0, 255, (size[1] // 8, size[0] // 8, 3), dtype=np.uint8))
    b = io.BytesIO(); Image.fromarray(a).resize(size, Image.NEAREST).save(b, 'JPEG'); return b.getvalue()
def z(members):
    b = io.BytesIO()
    with zipfile.ZipFile(b, 'w') as f:
        for k, v in members.items(): f.writestr(k, v)
    return {'mine.zip': b.getvalue()}
nb = json.loads((repo / 'tutorials/xoftr_image_matching_colab.ipynb').read_text())
c21 = next(''.join(c['source']) for c in nb['cells'] if 'USE_BYOD = False' in ''.join(c['source']))
branch = '\n'.join(l[4:] for l in c21.split('if USE_BYOD:\n', 1)[1].split('\nelse:', 1)[0].splitlines())
tail = c21.split('dataset_manifests = ', 1)[1].split('\ndisjoint', 1)[0]
code = branch + '\ndataset_manifests = ' + tail + '\n'
os.chdir(tempfile.mkdtemp())
def run(up):
    colab = types.ModuleType('google.colab'); colab.files = types.SimpleNamespace(upload=lambda: dict(up))
    sys.modules['google'] = types.ModuleType('google'); sys.modules['google.colab'] = colab
    g = {'Path': Path, 'load_byod_dataset': S.load_byod_dataset, 'split_dataset': S.split_dataset, 'validate_dataset': S.validate_dataset, 'SPLIT_SEED': 42}
    try:
        exec(code, g); return {'outcome': 'accepted', 'split': {k: m['n_records'] for k, m in g['dataset_manifests'].items()}}
    except BaseException as exc:
        return {'outcome': 'refused', 'error': f'{type(exc).__name__}: {exc}'[:200]}
res = {'stated_minimum': "at least eight (cell 0); a dataset needs 4..5,000 records (cell 1)", 'sweep': {}}
for n in (8, 12, 16, 20, 23, 24, 26):
    res['sweep'][n] = run(z({f'p{i:02d}.jpg': jpg(i) for i in range(n)}))
res['no_images'] = run(z({'readme.txt': b'hello'}))
res['corrupt_jpeg_among_30'] = run(z({**{f'p{i:02d}.jpg': jpg(i) for i in range(29)}, 'bad.jpg': b'not a jpeg'}))
res['tiny_image_among_30'] = run(z({**{f'p{i:02d}.jpg': jpg(i) for i in range(29)}, 'small.jpg': jpg(99, (40, 30))}))
res['cancelled_dialog'] = run({})
print(json.dumps(res, indent=1)); (out / 'p2.json').write_text(json.dumps(res, indent=1))
